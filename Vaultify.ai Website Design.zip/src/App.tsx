import './styles/globals.css';
import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { LoginModal } from './components/LoginModal';
import { MobileAppContainer } from './components/mobile/MobileAppContainer';
import { MembershipApplicationForm } from './components/MembershipApplicationForm';

// Pages
import { Home } from './pages/Home';
import { PrivateDealFlow } from './pages/PrivateDealFlow';
import { PortfolioIntelligence } from './pages/PortfolioIntelligence';
import { WealthConcierge } from './pages/WealthConcierge';
import { NetworkAccess } from './pages/NetworkAccess';
import { About } from './pages/About';
import { Philosophy } from './pages/Philosophy';
import { Membership } from './pages/Membership';
import { Contact } from './pages/Contact';
import { PrivacyPolicy } from './pages/PrivacyPolicy';
import { TermsOfService } from './pages/TermsOfService';
import { Disclosures } from './pages/Disclosures';
import { Security } from './pages/Security';

export default function App() {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showMembershipForm, setShowMembershipForm] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setShowLoginModal(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  const openMembershipForm = () => {
    setShowMembershipForm(true);
    setShowLoginModal(false);
  };

  return (
    <Router>
      <AnimatePresence mode="wait">
        {isLoggedIn ? (
          // Mobile app view - Full screen web app
          <motion.div
            key="app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="mobile-app-view"
          >
            {/* Logout button - positioned absolutely in top-right */}
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              onClick={handleLogout}
              className="absolute top-4 right-4 z-[60] px-4 py-2 rounded-full text-xs backdrop-blur-xl"
              style={{
                background: 'rgba(31, 31, 31, 0.8)',
                border: '1px solid rgba(212, 175, 122, 0.2)',
                color: '#F5F5F0',
                top: 'max(env(safe-area-inset-top), 1rem)',
              }}
            >
              ← Marketing
            </motion.button>
            
            {/* Mobile app - full screen */}
            <MobileAppContainer />
          </motion.div>
        ) : (
          // Marketing pages with routing
          <motion.div
            key="marketing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Routes>
              <Route path="/" element={<Home onLoginClick={() => setShowLoginModal(true)} onMembershipClick={openMembershipForm} />} />
              
              {/* Platform Routes */}
              <Route path="/platform/deal-flow" element={<PrivateDealFlow onMembershipClick={openMembershipForm} />} />
              <Route path="/platform/portfolio-intelligence" element={<PortfolioIntelligence onMembershipClick={openMembershipForm} />} />
              <Route path="/platform/wealth-concierge" element={<WealthConcierge onMembershipClick={openMembershipForm} />} />
              <Route path="/platform/network-access" element={<NetworkAccess onMembershipClick={openMembershipForm} />} />
              
              {/* Company Routes */}
              <Route path="/company/about" element={<About onMembershipClick={openMembershipForm} />} />
              <Route path="/company/philosophy" element={<Philosophy onMembershipClick={openMembershipForm} />} />
              <Route path="/company/membership" element={<Membership onMembershipClick={openMembershipForm} />} />
              <Route path="/company/contact" element={<Contact onMembershipClick={openMembershipForm} />} />
              
              {/* Legal Routes */}
              <Route path="/legal/privacy" element={<PrivacyPolicy />} />
              <Route path="/legal/terms" element={<TermsOfService />} />
              <Route path="/legal/disclosures" element={<Disclosures />} />
              <Route path="/legal/security" element={<Security />} />
              
              {/* Catch all - redirect to home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>

            {/* Login Modal */}
            <AnimatePresence>
              {showLoginModal && (
                <LoginModal 
                  onClose={() => setShowLoginModal(false)} 
                  onLogin={handleLogin}
                />
              )}
            </AnimatePresence>

            {/* Membership Application Form */}
            <AnimatePresence>
              {showMembershipForm && (
                <MembershipApplicationForm 
                  onClose={() => setShowMembershipForm(false)}
                />
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </Router>
  );
}
