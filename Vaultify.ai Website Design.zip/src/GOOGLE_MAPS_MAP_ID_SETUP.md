# 🗺️ Google Maps Map ID Setup Guide

## Why Do You Need a Map ID?

Google Maps requires a **Map ID** to use **Advanced Markers** - the custom HTML markers with champagne gold styling and price bubbles that make your Vaultify map look luxurious.

**Without a Map ID:** The map will use standard circular markers (still works, but less fancy)  
**With a Map ID:** You get custom HTML markers with your luxury branding

---

## 🚀 Quick Setup (5 Minutes)

### Step 1: Go to Google Cloud Console

Visit: [https://console.cloud.google.com/google/maps-apis/studio/maps](https://console.cloud.google.com/google/maps-apis/studio/maps)

**Make sure you're in the same project** where you created your API key.

---

### Step 2: Create a New Map ID

1. Click the **"Create Map ID"** button (or **"+ CREATE MAP ID"**)

2. Fill in the form:
   ```
   Map name: Vaultify Luxury Map
   Map type: JavaScript
   Description: Interactive luxury concierge map (optional)
   ```

3. Click **"Save"**

4. Your new Map ID will appear - it looks like this:
   ```
   a1b2c3d4e5f6g7h8
   ```
   or
   ```
   abc123def456
   ```

5. **Copy the Map ID** (it's a short alphanumeric string)

---

### Step 3: Add Map ID to Your Config

1. Open `/lib/config.ts`

2. Find this line (around line 35):
   ```typescript
   googleMapsMapId: 'DEMO_MAP_ID',
   ```

3. Replace `'DEMO_MAP_ID'` with your actual Map ID:
   ```typescript
   googleMapsMapId: 'a1b2c3d4e5f6g7h8', // Your actual Map ID
   ```

4. Save the file

---

### Step 4: Verify It Works

1. Refresh your Vaultify app
2. Login and go to Dashboard
3. Click the "Map" button
4. You should now see **luxury champagne gold markers** with:
   - Price bubbles (e.g., "$425K")
   - Custom icons
   - Smooth hover effects
   - Gradient animations

---

## 🎨 What Changes With a Map ID?

### Without Map ID (Standard Markers):
```
📍 Simple circular dots
   └─ Color: Champagne gold (#D4AF7A)
   └─ Label: Shows price
   └─ Hover: Slight scale effect
   └─ Style: Basic Google Maps marker
```

### With Map ID (Advanced Markers):
```
💎 Luxury custom markers
   └─ Custom HTML bubble design
   └─ Champagne gold gradients
   └─ Price + icon inside bubble
   └─ Smooth pulsing animation
   └─ Hover: Gradient color shift
   └─ Preview cards on hover
   └─ Fully branded experience
```

---

## 📸 Visual Comparison

**Standard Markers (No Map ID):**
- ⚪ Simple colored dots
- 🏷️ Text label next to dot
- Basic interaction

**Advanced Markers (With Map ID):**
- 🎨 Custom champagne gold bubbles
- 💰 Price displayed inside bubble
- 🏠 Icon inside bubble
- ✨ Gradient hover effects
- 📊 Rich preview cards

---

## 🔧 Troubleshooting

### Issue: Map ID field is grayed out

**Solution:** Make sure you have:
1. Maps JavaScript API enabled
2. Billing set up on your project
3. The correct project selected

### Issue: "Map ID not found" error

**Possible causes:**
1. **Wrong project:** Map ID must be in the same Google Cloud project as your API key
2. **Typo:** Double-check you copied the Map ID correctly
3. **Not saved:** Make sure you clicked "Save" after creating the Map ID

**Fix:**
1. Go back to [Map IDs page](https://console.cloud.google.com/google/maps-apis/studio/maps)
2. Verify the Map ID exists
3. Copy it again
4. Paste in `/lib/config.ts`

### Issue: Still seeing standard markers

**Check:**
1. Clear browser cache (Ctrl+Shift+R or Cmd+Shift+R)
2. Verify Map ID in config is correct (not 'DEMO_MAP_ID')
3. Check browser console for errors (F12)
4. Make sure the map has reloaded

### Issue: Console shows "Map ID is not configured"

**This is normal if:**
- You haven't created a Map ID yet
- The map will work with standard markers
- Advanced markers require a Map ID

**To fix:**
- Follow this guide to create a Map ID
- Add it to `/lib/config.ts`

---

## 🆓 Cost & Limits

**Good news:** Map IDs are **free** to create and use!

- **Creation:** Free, unlimited Map IDs
- **Usage:** No additional cost beyond standard Maps API usage
- **Storage:** Free, Map IDs don't expire

**Standard pricing still applies:**
- $200/month free credit
- $7 per 1,000 map loads after free tier

Advanced Markers don't cost extra - they're included in the standard Maps JavaScript API pricing.

---

## 📋 Quick Checklist

Before you start:
- [ ] You have a Google Cloud account
- [ ] You've created a Google Maps API key
- [ ] You've enabled Maps JavaScript API
- [ ] Billing is set up (required for Google Maps)

Creating Map ID:
- [ ] Navigate to Map IDs page in Google Cloud Console
- [ ] Click "Create Map ID"
- [ ] Name it "Vaultify Luxury Map"
- [ ] Select "JavaScript" as map type
- [ ] Click "Save"
- [ ] Copy the generated Map ID

Adding to Vaultify:
- [ ] Open `/lib/config.ts`
- [ ] Replace `'DEMO_MAP_ID'` with your Map ID
- [ ] Save the file
- [ ] Refresh your app

Testing:
- [ ] Map loads successfully
- [ ] Markers appear as luxury bubbles (not simple dots)
- [ ] Prices show inside bubbles
- [ ] Hover effects work
- [ ] Click to open experience details

---

## 🎯 Step-by-Step Screenshots Guide

### 1. Navigate to Map IDs
```
Google Cloud Console → APIs & Services → Map Management → Map IDs
```
Or use direct link: https://console.cloud.google.com/google/maps-apis/studio/maps

### 2. Click "Create Map ID"
Look for the button at the top right or center of the page

### 3. Fill in Details
```
┌─────────────────────────────────────┐
│ Create Map ID                       │
├─────────────────────────────────────┤
│ Map name: *                         │
│ [Vaultify Luxury Map          ]     │
│                                     │
│ Map type: *                         │
│ ○ Vector  ● JavaScript  ○ Raster    │
│                                     │
│ Description: (optional)             │
│ [Interactive luxury concierge map]  │
│                                     │
│         [Cancel]  [Save]            │
└─────────────────────────────────────┘
```

### 4. Copy Your Map ID
After saving, you'll see:
```
┌─────────────────────────────────────┐
│ Map ID: a1b2c3d4e5f6g7h8           │
│ [Copy]                              │
└─────────────────────────────────────┘
```

### 5. Add to Config
```typescript
// /lib/config.ts
export const config = {
  googleMapsApiKey: 'AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA',
  googleMapsMapId: 'a1b2c3d4e5f6g7h8', // ← Paste here
  // ...
};
```

---

## 💡 Pro Tips

1. **One Map ID is enough** - You can reuse the same Map ID across your entire app

2. **Naming convention** - Use descriptive names like "Vaultify-Production" and "Vaultify-Development" if you want separate Map IDs for different environments

3. **Map styling** - Map IDs allow you to save custom map styles in Google Cloud Console (but we're using code-based styling, so this is optional)

4. **Multiple Map IDs** - You can create multiple Map IDs for different maps if needed, but one is fine for Vaultify

5. **Testing** - Map IDs work immediately - no waiting for propagation

---

## 🔐 Security Notes

**Map IDs are safe to expose:**
- They're client-side identifiers
- Not secret like API keys
- Can be visible in your code
- No security risk if public

**Still, use restrictions:**
- Your API key should have domain restrictions
- This protects your API usage
- Map IDs inherit API key restrictions

---

## ✅ Success!

Once configured, you'll have:

✨ **Luxury Markers** - Custom champagne gold bubbles  
💰 **Price Display** - Prices shown inside markers  
🎨 **Gradient Effects** - Smooth color transitions on hover  
📍 **Interactive** - Click to view experiences  
🚀 **Professional** - Matches Vaultify branding  

Your map will look premium and align perfectly with the luxury aesthetic of Vaultify.ai!

---

## 🆘 Still Need Help?

**Common Questions:**

**Q: Can I skip creating a Map ID?**  
A: Yes! The map works without it, just with simpler markers.

**Q: How long does it take to create?**  
A: Less than 2 minutes if you follow this guide.

**Q: Will it cost extra?**  
A: No, Map IDs are free and don't add to your bill.

**Q: Can I change the Map ID later?**  
A: Yes, just update `/lib/config.ts` with a new Map ID.

**Q: Do I need one Map ID per marker?**  
A: No! One Map ID is used for the entire map.

---

## 📚 Related Guides

- **GOOGLE_MAPS_SETUP.md** - Initial API key setup
- **FIGMA_MAKE_SETUP.md** - Deployment guide
- **QUICK_TEST_GUIDE.md** - Testing instructions
- **MAP_VERIFICATION.md** - Verification checklist

---

**Ready to create your Map ID?** Head to [Google Cloud Console](https://console.cloud.google.com/google/maps-apis/studio/maps) and follow the steps above! 🚀

---

*Luxury that listens. Intelligence that acts.*
