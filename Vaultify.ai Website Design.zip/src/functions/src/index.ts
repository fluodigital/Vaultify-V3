import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

// Initialize Firebase Admin
admin.initializeApp();

// Export all function modules
export * from './auth';
export * from './bookings';
export * from './payments';
export * from './alfred';
export * from './emails';

// Health check endpoint
export const healthCheck = functions.https.onRequest((request, response) => {
  response.json({ status: 'ok', timestamp: new Date().toISOString() });
});
