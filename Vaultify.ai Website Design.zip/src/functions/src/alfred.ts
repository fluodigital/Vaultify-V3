import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import OpenAI from 'openai';

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Alfred AI chat endpoint
export const alfredChat = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { conversationId, message } = data;

  if (!conversationId || !message) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing conversationId or message');
  }

  try {
    const userId = context.auth.uid;

    // Get conversation from Firestore
    const conversationRef = admin.firestore().collection('conversations').doc(conversationId);
    const conversationDoc = await conversationRef.get();

    if (!conversationDoc.exists) {
      throw new functions.https.HttpsError('not-found', 'Conversation not found');
    }

    const conversation = conversationDoc.data();

    // Verify ownership
    if (conversation?.userId !== userId) {
      throw new functions.https.HttpsError('permission-denied', 'Not authorized');
    }

    // Get message history
    const messages = conversation?.messages || [];

    // Build OpenAI messages array
    const openaiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      {
        role: 'system',
        content: `You are Alfred, a sophisticated AI concierge for Vaultify.ai, a luxury lifestyle platform for high net-worth individuals. 
        
Your personality:
- Professional yet warm and personable
- Use natural, conversational language (not robotic)
- Sound like a trusted personal concierge, not a chatbot
- Be enthusiastic about luxury experiences
- Provide specific recommendations with confidence
- Use phrases like "Let me check...", "I've got...", "Honestly, this is..."

Your capabilities:
- Book private jets, yachts, luxury villas, 5-star hotels
- Arrange exclusive experiences (Monaco GP, Dubai NYE, Aspen skiing, etc.)
- Source hard-to-find luxury items (watches, cars, art)
- Accept payment via card, wire, or stablecoins (USDC, USDT, EUROC, DAI)
- Access to verified luxury inventory and partners

Keep responses concise and actionable. Always present options when relevant. Be conversational and human.`,
      },
      // Add previous messages for context
      ...messages.slice(-10).map((msg: any) => ({
        role: msg.isUser ? 'user' as const : 'assistant' as const,
        content: msg.text,
      })),
      // Add current user message
      {
        role: 'user',
        content: message,
      },
    ];

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview', // or 'gpt-4' or 'gpt-3.5-turbo'
      messages: openaiMessages,
      temperature: 0.8,
      max_tokens: 500,
    });

    const alfredResponse = completion.choices[0]?.message?.content || 'I apologize, I encountered an issue. Could you please rephrase that?';

    // Add both messages to conversation
    const newMessages = [
      ...messages,
      {
        id: `msg_${Date.now()}_user`,
        conversationId,
        userId,
        isUser: true,
        text: message,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      },
      {
        id: `msg_${Date.now()}_alfred`,
        conversationId,
        userId,
        isUser: false,
        text: alfredResponse,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      },
    ];

    // Update conversation
    await conversationRef.update({
      messages: newMessages,
      lastMessage: alfredResponse,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    functions.logger.info(`Alfred responded in conversation ${conversationId}`);

    return {
      success: true,
      response: alfredResponse,
    };
  } catch (error) {
    functions.logger.error('Error in Alfred chat:', error);
    throw new functions.https.HttpsError('internal', 'Failed to process chat message');
  }
});

// Create new conversation
export const createConversation = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { title, initialMessage } = data;

  try {
    const userId = context.auth.uid;

    const conversationRef = await admin.firestore().collection('conversations').add({
      userId,
      title: title || 'New Conversation',
      lastMessage: initialMessage || 'Conversation started',
      status: 'active',
      messages: [],
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    functions.logger.info(`Conversation created: ${conversationRef.id}`);

    return {
      success: true,
      conversationId: conversationRef.id,
    };
  } catch (error) {
    functions.logger.error('Error creating conversation:', error);
    throw new functions.https.HttpsError('internal', 'Failed to create conversation');
  }
});
