# 🚨 FIX REFERER ERROR NOW (2 Minutes)

## What You're Seeing
```
❌ RefererNotAllowedMapError
```

## The Fix (Copy-Paste Ready)

### 1. Open This Link
👉 [https://console.cloud.google.com/apis/credentials](https://console.cloud.google.com/apis/credentials)

### 2. Click Your API Key
Look for: `AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA`

### 3. Under "Application restrictions"
Select: `● HTTP referrers (web sites)`

### 4. Copy-Paste These Domains

```
*.figma.site/*
*.figma.com/*
localhost:*
```

**How to add:**
1. Paste first domain: `*.figma.site/*`
2. Press Enter or click "+ Add an item"
3. Paste second domain: `*.figma.com/*`
4. Press Enter or click "+ Add an item"
5. Paste third domain: `localhost:*`

### 5. Click "Save"

### 6. Wait 2 Minutes

### 7. Refresh Figma Make Preview
Press: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac)

---

## ✅ Done!

Your map should now load without errors.

---

## Still Broken?

1. **Wait longer** - Can take up to 5 minutes
2. **Check spelling** - Must be exactly `*.figma.site/*` with asterisks
3. **Verify API key** - Make sure you edited the right one
4. **Clear cache** - Try incognito/private browsing

---

## Screenshot Guide

```
┌──────────────────────────────────────┐
│ Application restrictions             │
├──────────────────────────────────────┤
│ ○ None                               │
│ ● HTTP referrers (web sites) ← THIS │
│ ○ IP addresses                       │
│                                      │
│ Website restrictions                 │
│ ┌──────────────────────────────┐    │
│ │ 1. *.figma.site/*           │    │
│ │ 2. *.figma.com/*            │    │
│ │ 3. localhost:*              │    │
│ │ + Add an item                │    │
│ └──────────────────────────────┘    │
│                                      │
│              [Save] ← CLICK          │
└──────────────────────────────────────┘
```

---

**2 minutes to fix. Do it now! →** [Open Console](https://console.cloud.google.com/apis/credentials)
