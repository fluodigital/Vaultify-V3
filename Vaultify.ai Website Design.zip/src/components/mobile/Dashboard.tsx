import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plane, Home, Hotel, Car, Sparkles, ChevronRight, TrendingUp, Clock, MapPin, Star, Building2, Mountain, Palmtree, Flag, Watch, Ship } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ExperienceData } from './ExperienceDetail';
import { InteractiveMap } from './InteractiveMap';

interface DashboardProps {
  onOpenAlfred: () => void;
  onExperienceSelect?: (experience: ExperienceData) => void;
  showMapToggle?: boolean;
  onMapMarkerSelectionChange?: (isSelected: boolean) => void;
}

const categories = [
  {
    icon: Plane,
    label: 'Private Jets',
    count: '8 available',
    gradient: 'from-blue-500/20 to-cyan-500/20',
  },
  {
    icon: Home,
    label: 'Villas',
    count: '12 properties',
    gradient: 'from-purple-500/20 to-pink-500/20',
  },
  {
    icon: Hotel,
    label: 'Hotels',
    count: '24 locations',
    gradient: 'from-orange-500/20 to-red-500/20',
  },
  {
    icon: Car,
    label: 'Chauffeur',
    count: '6 services',
    gradient: 'from-green-500/20 to-emerald-500/20',
  },
];

const curatedExperiences: ExperienceData[] = [
  {
    id: 'monaco-gp',
    title: 'Monaco Grand Prix Weekend',
    location: 'Monaco',
    price: '£425K',
    image: 'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    details: 'Yacht • Suite • Race Paddock',
    tag: 'Exclusive',
    description: 'Experience the pinnacle of motorsport luxury with our all-inclusive Monaco Grand Prix package. Stay in the finest suite at Hotel de Paris, enjoy VIP paddock access, and watch the race from your private 180ft yacht in Port Hercules. Every detail curated for the ultimate racing weekend.',
    duration: '4 Days / 3 Nights',
    maxGuests: 'Up to 8 Guests',
    highlights: [
      'VIP Paddock Club access with driver meet & greet',
      'Private 180ft yacht charter in Port Hercules with race views',
      'Hotel de Paris Diamond Suite with Monaco harbor views',
      'Champagne reception with team principals',
      'Helicopter transfers from Nice Airport',
      'Private guided tour of Monaco by night'
    ],
    inclusions: [
      'Luxury accommodation at Hotel de Paris (3 nights)',
      '180ft Azimut yacht charter with crew and catering',
      'VIP Grand Prix paddock passes for all guests',
      'All helicopter transfers and ground transportation',
      'Fine dining reservations at Le Louis XV and Cipriani',
      'Personal concierge throughout your stay',
      'Photographer to capture your weekend',
      'Welcome gift: Limited edition timepiece'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1664953059029-18bd03bd64eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBob3RlbCUyMHBhcmlzfGVufDF8fHx8MTc2MTA2ODMyNXww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1623258406180-df4c68d0798f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFuZCUyMHByaXglMjByYWNpbmd8ZW58MXx8fHwxNzYxMDY4MzI2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1745305023239-b476a0faa159?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB3YXRjaCUyMHBhdGVrfGVufDF8fHx8MTc2MTA2NzY1Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'aspen-winter',
    title: 'Aspen Winter Escape',
    location: 'Aspen, Colorado',
    price: '£185K',
    image: 'https://images.unsplash.com/photo-1678044488372-5f282f0b3f21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3BlbiUyMGx1eHVyeSUyMHNraWluZ3xlbnwxfHx8fDE3NjEwNjc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    details: 'Chalet • Helicopter • Ski Guide',
    tag: 'Trending',
    description: 'Escape to the Rocky Mountains for the ultimate winter luxury experience. Your private 8-bedroom chalet features ski-in/ski-out access, private chef, and dedicated staff. Enjoy helicopter skiing on virgin powder, exclusive après-ski experiences, and world-class dining in America\'s premier ski destination.',
    duration: '7 Days / 6 Nights',
    maxGuests: 'Up to 12 Guests',
    highlights: [
      'Private 8-bedroom ski chalet with mountain views',
      'Helicopter skiing on untouched Rocky Mountain terrain',
      'Professional ski instructor and mountain guide',
      'Private wine tasting with sommelier',
      'Snowcat dinner experience at 11,000 feet',
      'Spa treatments in your chalet'
    ],
    inclusions: [
      'Exclusive luxury chalet with full staff (6 nights)',
      'Private chef for all meals and après-ski',
      'Two helicopter skiing days with experienced guides',
      'VIP lift passes and ski equipment',
      'Daily spa treatments and massage therapy',
      'Ground transportation including Escalade SUV',
      'Reservations at Aspen\'s finest restaurants',
      'Snowmobiling and winter activities'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1709508496457-e2f9c42493c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBza2klMjBjaGFsZXR8ZW58MXx8fHwxNzYxMDY4MzI2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1678044488372-5f282f0b3f21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3BlbiUyMGx1eHVyeSUyMHNraWluZ3xlbnwxfHx8fDE3NjEwNjc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'maldives-island',
    title: 'Maldives Private Island',
    location: 'North Malé Atoll',
    price: '£320K',
    image: 'https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGx1eHVyeSUyMHJlc29ydHxlbnwxfHx8fDE3NjA5NzI5MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    details: 'Villa • Seaplane • Chef',
    tag: 'Popular',
    description: 'Your own private island paradise in the Maldives awaits. This exclusive 10-day escape features an overwater villa, private yacht, personal chef, and dedicated staff. Dive into crystal-clear waters, enjoy sunset cruises, and experience the ultimate in tropical luxury and privacy.',
    duration: '10 Days / 9 Nights',
    maxGuests: 'Up to 6 Guests',
    highlights: [
      'Private overwater villa with infinity pool',
      'Personal yacht for island hopping and diving',
      'Michelin-trained private chef',
      'Seaplane transfers with aerial tour',
      'Private sandbank dinner under the stars',
      'Couples spa treatments on the beach'
    ],
    inclusions: [
      'Overwater residence with butler service (9 nights)',
      'Private 60ft yacht with captain and crew',
      'All seaplane transfers from Malé',
      'Personal chef and mixologist',
      'Unlimited water sports and diving',
      'Daily spa treatments and wellness sessions',
      'Private excursions including night fishing and dolphin watching',
      'Underwater dining experience'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1692417045306-bb61bfe7afd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMG92ZXJ3YXRlciUyMGJ1bmdhbG93fGVufDF8fHx8MTc2MTAzMDgzMHww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGx1eHVyeSUyMHJlc29ydHxlbnwxfHx8fDE3NjA5NzI5MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'santorini-escape',
    title: 'Santorini Cliffside Escape',
    location: 'Santorini, Greece',
    price: '£165K',
    image: 'https://images.unsplash.com/photo-1628024420612-4640108b4902?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBsdXh1cnklMjBob3RlbHxlbnwxfHx8fDE3NjI1MTA5NjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    details: 'Villa • Private Pool • Sunset Views',
    tag: 'New',
    description: 'Perched on the famous caldera cliffs of Santorini, this exclusive villa offers breathtaking sunset views over the Aegean Sea. Enjoy private infinity pools, personal chef services, and curated wine tastings from local vineyards.',
    duration: '5 Days / 4 Nights',
    maxGuests: 'Up to 4 Guests',
    highlights: [
      'Cliffside villa with infinity pool',
      'Private yacht day cruise around the caldera',
      'Wine tasting at exclusive vineyards',
      'Professional photography session at sunset',
      'Private chef preparing Greek cuisine',
      'Helicopter tour of the Cyclades'
    ],
    inclusions: [
      'Luxury cliffside villa (4 nights)',
      'Daily breakfast and dinner by private chef',
      'Private yacht cruise with lunch',
      'Wine tasting experiences',
      'All transfers including helicopter',
      'Personal photographer for one session',
      'Spa treatments in villa',
      'Private tours of Oia and Fira'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1628024420612-4640108b4902?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBsdXh1cnklMjBob3RlbHxlbnwxfHx8fDE3NjI1MTA5NjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGx1eHVyeSUyMHJlc29ydHxlbnwxfHx8fDE3NjA5NzI5MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'dubai-sky',
    title: 'Dubai Sky Experience',
    location: 'Dubai, UAE',
    price: '£295K',
    image: 'https://images.unsplash.com/photo-1735320864239-798f9bd96c3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMHBlbnRob3VzZSUyMGx1eHVyeXxlbnwxfHx8fDE3NjI1MTA5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    details: 'Penthouse • Supercar • Desert Safari',
    tag: 'Premium',
    description: 'Experience Dubai\'s ultra-modern luxury with a penthouse suite at Burj Khalifa, exotic supercar fleet access, and exclusive desert experiences. From helicopter tours to private beach clubs, discover the pinnacle of Arabian hospitality.',
    duration: '6 Days / 5 Nights',
    maxGuests: 'Up to 6 Guests',
    highlights: [
      'Burj Khalifa penthouse suite',
      'Fleet of supercars (Ferrari, Lamborghini, Rolls-Royce)',
      'Private helicopter tour of Dubai',
      'VIP access to exclusive beach clubs',
      'Luxury desert safari with private camp',
      'Shopping experience with personal stylist'
    ],
    inclusions: [
      'Penthouse accommodation (5 nights)',
      'Supercar access throughout stay',
      'Helicopter tours and transfers',
      'Private yacht charter in Dubai Marina',
      'Desert safari with gourmet dining',
      'All fine dining reservations',
      'Personal butler and driver',
      'Access to private lounges and clubs'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1735320864239-798f9bd96c3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMHBlbnRob3VzZSUyMGx1eHVyeXxlbnwxfHx8fDE3NjI1MTA5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'paris-elegance',
    title: 'Parisian Elegance',
    location: 'Paris, France',
    price: '£220K',
    image: 'https://images.unsplash.com/photo-1633159440827-a7552a0665b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGx1eHVyeSUyMGFwYXJ0bWVudHxlbnwxfHx8fDE3NjI0NTg0NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    details: 'Apartment • Michelin Dining • Fashion Week',
    tag: 'Exclusive',
    description: 'Live like Parisian royalty in a historic Haussmann apartment with Eiffel Tower views. Experience exclusive fashion shows, private museum tours, and Michelin-starred dining. A curated journey through the City of Light\'s finest offerings.',
    duration: '5 Days / 4 Nights',
    maxGuests: 'Up to 4 Guests',
    highlights: [
      'Historic apartment with Eiffel Tower views',
      'Private tours of Louvre and Versailles',
      'Front row seats at Fashion Week shows',
      'Michelin-starred restaurant reservations',
      'Private Seine river cruise with champagne',
      'Personal shopping at haute couture houses'
    ],
    inclusions: [
      'Luxury Haussmann apartment (4 nights)',
      'Private museum and palace tours',
      'Fashion Week access and styling',
      'All fine dining experiences',
      'Chauffeur service throughout',
      'Private yacht on the Seine',
      'Personal photographer',
      'VIP nightlife access'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1633159440827-a7552a0665b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGx1eHVyeSUyMGFwYXJ0bWVudHxlbnwxfHx8fDE3NjI0NTg0NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'bali-retreat',
    title: 'Bali Wellness Retreat',
    location: 'Ubud, Bali',
    price: '£145K',
    image: 'https://images.unsplash.com/photo-1729720281771-b790dfb6ec7f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBiZWFjaCUyMHZpbGxhfGVufDF8fHx8MTc2MjUxMDk2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    details: 'Villa • Spa • Wellness',
    tag: 'Wellness',
    description: 'Find tranquility in a secluded jungle villa overlooking rice terraces. This wellness-focused retreat includes daily spa treatments, yoga sessions, organic cuisine, and spiritual healing experiences in Bali\'s most serene setting.',
    duration: '8 Days / 7 Nights',
    maxGuests: 'Up to 4 Guests',
    highlights: [
      'Private villa with rice terrace views',
      'Daily yoga and meditation sessions',
      'Traditional Balinese healing ceremonies',
      'Organic farm-to-table cuisine',
      'Private spa pavilion with treatments',
      'Sunrise trekking and temple visits'
    ],
    inclusions: [
      'Exclusive jungle villa (7 nights)',
      'Personal wellness instructor',
      'All spa and healing treatments',
      'Organic meals by private chef',
      'Private driver for excursions',
      'Temple ceremonies and blessings',
      'Wellness program customization',
      'Cultural immersion experiences'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1729720281771-b790dfb6ec7f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBiZWFjaCUyMHZpbGxhfGVufDF8fHx8MTc2MjUxMDk2Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMGx1eHVyeSUyMHJlc29ydHxlbnwxfHx8fDE3NjA5NzI5MzN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
  {
    id: 'safari-adventure',
    title: 'African Safari Expedition',
    location: 'Serengeti, Tanzania',
    price: '£275K',
    image: 'https://images.unsplash.com/photo-1762254804915-967868db1ece?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzYWZhcmklMjB0ZW50fGVufDF8fHx8MTc2MjUxMDk2M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    details: 'Safari Lodge • Wildlife • Hot Air Balloon',
    tag: 'Adventure',
    description: 'Witness the great migration from your luxury tented camp. This once-in-a-lifetime safari includes private game drives, hot air balloon rides over the Serengeti, and intimate encounters with Africa\'s magnificent wildlife.',
    duration: '9 Days / 8 Nights',
    maxGuests: 'Up to 6 Guests',
    highlights: [
      'Luxury tented camp in prime wildlife area',
      'Private game drives with expert guides',
      'Hot air balloon safari at sunrise',
      'Visit to Maasai villages',
      'Bush dinners under the stars',
      'Photography masterclass with professional'
    ],
    inclusions: [
      'Premium safari lodge accommodation (8 nights)',
      'All game drives and park fees',
      'Hot air balloon experience',
      'Private bush flights between camps',
      'Expert wildlife guides',
      'All gourmet meals and beverages',
      'Cultural experiences',
      'Professional photography session'
    ],
    gallery: [
      'https://images.unsplash.com/photo-1762254804915-967868db1ece?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzYWZhcmklMjB0ZW50fGVufDF8fHx8MTc2MjUxMDk2M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      'https://images.unsplash.com/photo-1686868245180-d5c984a984f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25hY28lMjBsdXh1cnklMjB5YWNodHxlbnwxfHx8fDE3NjEwNjc2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1625513123245-fcb02d69ad12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwamV0JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzYxMDQ2ODQwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1568115286680-d203e08a8be6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjB2aWV3fGVufDF8fHx8MTc2MTAzMzcwM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    ]
  },
];

const quickActions = [
  { icon: Plane, label: 'Book Jet', color: '#60a5fa' },
  { icon: Hotel, label: 'Find Hotel', color: '#f59e0b' },
  { icon: Car, label: 'Chauffeur', color: '#10b981' },
  { icon: Sparkles, label: 'Surprise Me', color: '#D4AF7A' },
];

// Map markers with actual lat/lng coordinates
const mapMarkers = [
  { id: 'monaco-gp', price: '$425K', experienceId: 'monaco-gp', lat: 43.7384, lng: 7.4246, city: 'Monaco' },
  { id: 'aspen', price: '$185K', experienceId: 'aspen-winter', lat: 39.1911, lng: -106.8175, city: 'Aspen' },
  { id: 'maldives', price: '$320K', experienceId: 'maldives-island', lat: 4.1755, lng: 73.5093, city: 'Maldives' },
  { id: 'dubai', price: '$280K', experienceId: 'monaco-gp', lat: 25.2048, lng: 55.2708, city: 'Dubai' },
  { id: 'tokyo', price: '$195K', experienceId: 'aspen-winter', lat: 35.6762, lng: 139.6503, city: 'Tokyo' },
  { id: 'paris', price: '$240K', experienceId: 'maldives-island', lat: 48.8566, lng: 2.3522, city: 'Paris' },
  { id: 'nyc', price: '$310K', experienceId: 'monaco-gp', lat: 40.7128, lng: -74.0060, city: 'New York' },
  { id: 'london', price: '$265K', experienceId: 'aspen-winter', lat: 51.5074, lng: -0.1278, city: 'London' },
  { id: 'bali', price: '$175K', experienceId: 'maldives-island', lat: -8.3405, lng: 115.0920, city: 'Bali' },
  { id: 'swiss', price: '$290K', experienceId: 'aspen-winter', lat: 46.8182, lng: 8.2275, city: 'Swiss Alps' },
];

export function Dashboard({ onOpenAlfred, onExperienceSelect, showMapToggle = true, onMapMarkerSelectionChange }: DashboardProps) {
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [isMarkerSelected, setIsMarkerSelected] = useState(false);

  const handleMarkerSelectionChange = (isSelected: boolean) => {
    setIsMarkerSelected(isSelected);
    onMapMarkerSelectionChange?.(isSelected);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="h-full overflow-y-auto bg-[#000000] relative">
      {/* Header with personalization - Hide when in map view */}
      <div className={`px-6 pt-6 pb-6 ${viewMode === 'map' ? 'hidden' : ''}`}>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-3">
            <p className="text-sm text-[#F5F5F0]/60 mb-1">{getGreeting()}</p>
            <h1 className="text-3xl text-[#F5F5F0]">
              <span className="italic">Marcus</span>
            </h1>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <p className="text-sm text-[#F5F5F0]/60">
              Alfred is ready • Response time: {'<'}12s
            </p>
          </div>
        </motion.div>
      </div>

      {/* Map View */}
      {viewMode === 'map' ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute top-0 left-0 right-0 bottom-0 z-30"
        >
          <InteractiveMap 
            markers={mapMarkers} 
            experiences={curatedExperiences}
            onExperienceSelect={onExperienceSelect}
            onMarkerSelectionChange={handleMarkerSelectionChange}
          />
        </motion.div>
      ) : (
        /* List View */
        <>
          {/* Enhanced Stats Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="px-6 mb-6"
          >
        <div
          className="p-6 rounded-2xl backdrop-blur-sm relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(184,147,94,0.15), rgba(212,175,122,0.08))',
            border: '1px solid rgba(212,175,122,0.25)',
          }}
        >
          {/* Decorative gradient orb */}
          <div 
            className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20"
            style={{
              background: 'linear-gradient(135deg, #B8935E, #D4AF7A)',
            }}
          />
          
          <div className="relative">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-xs uppercase tracking-wider text-[#F5F5F0]/50 mb-2">
                  Active Bookings
                </p>
                <p className="text-4xl text-[#F5F5F0] mb-1">3</p>
                <div className="flex items-center gap-1 text-xs text-green-400">
                  <TrendingUp size={12} />
                  <span>+2 this week</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-wider text-[#F5F5F0]/50 mb-2">
                  This Month
                </p>
                <p
                  className="text-4xl mb-1"
                  style={{
                    background: 'linear-gradient(135deg, #B8935E, #D4AF7A, #E6D5B8)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    color: 'transparent',
                  }}
                >
                  £284K
                </p>
                <p className="text-xs text-[#F5F5F0]/50">Across 5 bookings</p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="px-6 mb-6"
      >
        <h2 className="text-xs uppercase tracking-wider text-[#F5F5F0]/60 mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.button
                key={action.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.05 }}
                onClick={onOpenAlfred}
                className="flex flex-col items-center gap-2 p-3 rounded-xl"
                style={{
                  background: 'rgba(45,45,45,0.8)',
                  border: '1px solid rgba(212,175,122,0.1)',
                }}
                whileTap={{ scale: 0.95 }}
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{
                    background: `${action.color}15`,
                  }}
                >
                  <Icon size={18} style={{ color: action.color }} />
                </div>
                <span className="text-xs text-[#F5F5F0]/70 text-center">
                  {action.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* Search Bar */}
      <div className="px-6 mb-5">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          onClick={onOpenAlfred}
          className="flex items-center gap-3 px-4 py-3 rounded-full cursor-pointer"
          style={{
            background: 'rgba(45,45,45,0.8)',
            border: '1px solid rgba(212,175,122,0.15)',
          }}
        >
          <div className="text-[#D4AF7A]">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.35-4.35"/>
            </svg>
          </div>
          <span className="text-sm text-[#F5F5F0]/50">Start your search</span>
        </motion.div>
      </div>

      {/* Horizontal Tab Navigation */}
      <div className="px-6 mb-5">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex items-center gap-6 overflow-x-auto no-scrollbar"
        >
          {['For you', 'Sweet deals', 'Skiing', 'Ocean'].map((tab, index) => (
            <button
              key={tab}
              className="shrink-0 pb-3 relative"
              style={{
                borderBottom: index === 0 ? '2px solid #D4AF7A' : '2px solid transparent',
              }}
            >
              <span 
                className="text-sm whitespace-nowrap"
                style={{
                  color: index === 0 ? '#F5F5F0' : '#F5F5F0',
                  opacity: index === 0 ? 1 : 0.5,
                }}
              >
                {tab}
              </span>
            </button>
          ))}
        </motion.div>
      </div>

      {/* Hit the slopes section */}
      <div className="mb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="px-6 mb-3 flex items-center justify-between"
        >
          <h2 className="text-lg text-[#F5F5F0]">
            Hit the slopes
          </h2>
          <ChevronRight size={20} className="text-[#F5F5F0]/60" />
        </motion.div>

        <div className="overflow-x-auto no-scrollbar">
          <div className="flex gap-4 px-6">
            {[
              {
                location: 'TRUCKEE, CALIFORNIA',
                name: 'Tahoe Slopes',
                price: 'From $584/night',
                guests: 3,
                beds: 2,
                baths: 8,
                image: 'https://images.unsplash.com/photo-1678044488372-5f282f0b3f21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3BlbiUyMGx1eHVyeSUyMHNraWluZ3xlbnwxfHx8fDE3NjEwNjc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
              },
              {
                location: 'BIG SKY, MONTANA',
                name: 'Big Sky Resort',
                price: 'From $819/night',
                guests: 4,
                beds: 3,
                baths: 6,
                image: 'https://images.unsplash.com/photo-1709508496457-e2f9c42493c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBza2klMjBjaGFsZXR8ZW58MXx8fHwxNzYxMDY4MzI2fDA&ixlib=rb-4.1.0&q=80&w=1080'
              },
              {
                location: 'ASPEN, COLORADO',
                name: 'Aspen Chalet',
                price: 'From $1,240/night',
                guests: 6,
                beds: 4,
                baths: 10,
                image: 'https://images.unsplash.com/photo-1605037511300-355234c46bb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2klMjByZXNvcnQlMjBsdXh1cnl8ZW58MXx8fHwxNzMwNDYxNzg4fDA&ixlib=rb-4.1.0&q=80&w=1080'
              },
              {
                location: 'ZERMATT, SWITZERLAND',
                name: 'Alpine Retreat',
                price: 'From $1,580/night',
                guests: 8,
                beds: 5,
                baths: 12,
                image: 'https://images.unsplash.com/photo-1633974242338-e87a5e02214c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzd2lzcyUyMGFscHMlMjBjaGFsZXR8ZW58MXx8fHwxNzYyNTEwOTYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
              },
              {
                location: 'WHISTLER, CANADA',
                name: 'Mountain Lodge',
                price: 'From $920/night',
                guests: 5,
                beds: 4,
                baths: 9,
                image: 'https://images.unsplash.com/photo-1678044488372-5f282f0b3f21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3BlbiUyMGx1eHVyeSUyMHNraWluZ3xlbnwxfHx8fDE3NjEwNjc2NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080'
              },
              {
                location: 'COURCHEVEL, FRANCE',
                name: 'Courchevel 1850',
                price: 'From $2,100/night',
                guests: 10,
                beds: 6,
                baths: 14,
                image: 'https://images.unsplash.com/photo-1709508496457-e2f9c42493c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBza2klMjBjaGFsZXR8ZW58MXx8fHwxNzYxMDY4MzI2fDA&ixlib=rb-4.1.0&q=80&w=1080'
              },
            ].map((property, index) => (
              <motion.button
                key={property.name}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
                onClick={() => onExperienceSelect?.(curatedExperiences[1])}
                className="shrink-0 w-[240px] group"
              >
                <div className="relative mb-3 rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src={property.image}
                    alt={property.name}
                    className="w-full h-[260px] object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  
                  {/* Gradient overlay at bottom */}
                  <div 
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 40%)',
                    }}
                  />
                  
                  {/* Heart icon */}
                  <div 
                    className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md cursor-pointer z-10"
                    style={{
                      background: 'rgba(0,0,0,0.3)',
                      border: '1px solid rgba(255,255,255,0.2)',
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F5F5F0" strokeWidth="2">
                      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                  </div>
                </div>

                <div className="text-left">
                  <p className="text-xs text-[#F5F5F0]/50 mb-1 tracking-wide">
                    {property.location}
                  </p>
                  <h3 className="text-sm text-[#F5F5F0] mb-2">
                    {property.name}
                  </h3>
                  <p className="text-sm text-[#F5F5F0]/90 mb-2">
                    {property.price}
                  </p>
                  <div className="flex items-center gap-3 text-xs text-[#F5F5F0]/60">
                    <div className="flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                      </svg>
                      <span>{property.guests}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="11" width="18" height="10" rx="2"/>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                      </svg>
                      <span>{property.beds}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M12 1v6m0 6v6"/>
                      </svg>
                      <span>{property.baths}</span>
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Homes our guests love section */}
      <div className="mb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="px-6 mb-3 flex items-center justify-between"
        >
          <h2 className="text-lg text-[#F5F5F0]">
            Homes our guests love
          </h2>
          <ChevronRight size={20} className="text-[#F5F5F0]/60" />
        </motion.div>

        <div className="overflow-x-auto no-scrollbar">
          <div className="flex gap-4 px-6">
            {curatedExperiences.map((exp, index) => (
              <motion.button
                key={exp.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                onClick={() => onExperienceSelect?.(exp)}
                className="shrink-0 w-[240px] group"
              >
                <div className="relative mb-3 rounded-2xl overflow-hidden">
                  <ImageWithFallback
                    src={exp.image}
                    alt={exp.title}
                    className="w-full h-[260px] object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  
                  {/* Gradient overlay at bottom */}
                  <div 
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 40%)',
                    }}
                  />
                  
                  {/* Heart icon */}
                  <div 
                    className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md cursor-pointer z-10"
                    style={{
                      background: 'rgba(0,0,0,0.3)',
                      border: '1px solid rgba(255,255,255,0.2)',
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F5F5F0" strokeWidth="2">
                      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                  </div>

                  {/* Tag */}
                  {exp.tag && (
                    <div
                      className="absolute top-3 left-3 px-2 py-1 rounded-lg text-xs backdrop-blur-xl"
                      style={{
                        background: 'linear-gradient(135deg, rgba(184,147,94,0.9), rgba(212,175,122,0.8))',
                        color: '#000000',
                      }}
                    >
                      {exp.tag}
                    </div>
                  )}
                </div>

                <div className="text-left">
                  <p className="text-xs text-[#F5F5F0]/50 mb-1 tracking-wide uppercase">
                    {exp.location}
                  </p>
                  <h3 className="text-sm text-[#F5F5F0] mb-2">
                    {exp.title}
                  </h3>
                  <p 
                    className="text-sm mb-2"
                    style={{
                      background: 'linear-gradient(135deg, #B8935E, #D4AF7A, #E6D5B8)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      color: 'transparent',
                    }}
                  >
                    {exp.price}
                  </p>
                  <p className="text-xs text-[#F5F5F0]/60">
                    {exp.details}
                  </p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Trending Now */}
      <div className="px-6 mb-6">
        <motion.h2
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-xs uppercase tracking-wider text-[#F5F5F0]/60 mb-3 flex items-center gap-2"
        >
          <TrendingUp size={14} style={{ color: '#D4AF7A' }} />
          Trending Destinations
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="space-y-3"
        >
          {[
            { destination: 'Dubai, UAE', demand: '87% booked', Icon: Building2, iconColor: '#60a5fa' },
            { destination: 'St. Moritz, Switzerland', demand: '92% booked', Icon: Mountain, iconColor: '#a78bfa' },
            { destination: 'Bora Bora, French Polynesia', demand: '78% booked', Icon: Palmtree, iconColor: '#34d399' },
          ].map((item, index) => (
            <motion.button
              key={item.destination}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1 + index * 0.1 }}
              onClick={onOpenAlfred}
              className="w-full flex items-center justify-between p-4 rounded-xl group"
              style={{
                background: 'rgba(45,45,45,0.6)',
                border: '1px solid rgba(212,175,122,0.1)',
              }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center"
                  style={{
                    background: `${item.iconColor}15`,
                  }}
                >
                  <item.Icon size={18} style={{ color: item.iconColor }} />
                </div>
                <div className="text-left">
                  <p className="text-sm text-[#F5F5F0]">{item.destination}</p>
                  <p className="text-xs text-[#F5F5F0]/50">{item.demand}</p>
                </div>
              </div>
              <ChevronRight 
                size={16} 
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: '#D4AF7A' }} 
              />
            </motion.button>
          ))}
        </motion.div>
      </div>

      {/* Recent Activity */}
      <div className="px-6 mb-6">
        <motion.h2
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 1.1 }}
          className="text-xs uppercase tracking-wider text-[#F5F5F0]/60 mb-3 flex items-center gap-2"
        >
          <Clock size={14} style={{ color: '#D4AF7A' }} />
          Recent Activity
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="space-y-3"
        >
          {[
            { action: 'Monaco Experience', time: '2 hours ago', status: 'Confirmed', Icon: Flag, iconColor: '#D4AF7A' },
            { action: 'Patek Nautilus 5711', time: '2 hours ago', status: 'Secured', Icon: Watch, iconColor: '#f59e0b' },
            { action: 'Azimut Yacht Charter', time: '2 hours ago', status: 'Ready', Icon: Ship, iconColor: '#60a5fa' },
          ].map((item, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 rounded-xl"
              style={{
                background: 'rgba(45,45,45,0.6)',
                border: '1px solid rgba(212,175,122,0.1)',
              }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center"
                  style={{
                    background: `${item.iconColor}15`,
                  }}
                >
                  <item.Icon size={18} style={{ color: item.iconColor }} />
                </div>
                <div>
                  <p className="text-sm text-[#F5F5F0]">{item.action}</p>
                  <p className="text-xs text-[#F5F5F0]/50">{item.time}</p>
                </div>
              </div>
              <div
                className="text-xs px-3 py-1 rounded-full"
                style={{
                  background: 'rgba(212,175,122,0.1)',
                  color: '#D4AF7A',
                  border: '1px solid rgba(212,175,122,0.2)',
                }}
              >
                {item.status}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Ask Alfred CTA */}
      <div className="px-6 pb-8">
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.3 }}
          onClick={onOpenAlfred}
          className="w-full py-4 rounded-xl text-[#000000] relative overflow-hidden group"
          style={{
            background: 'linear-gradient(135deg, #B8935E, #D4AF7A, #E6D5B8)',
          }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center justify-center gap-2 relative z-10">
            <Sparkles size={20} />
            <span className="uppercase tracking-wider text-sm">Ask Alfred Anything</span>
          </div>
          
          {/* Shimmer effect */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
            animate={{
              x: ['-200%', '200%']
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'linear',
              repeatDelay: 1
            }}
          />
        </motion.button>
      </div>
        </>
      )}

      {/* Floating Map/List Toggle Button - Overlays content at bottom */}
      {showMapToggle && !isMarkerSelected && (
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          onClick={() => setViewMode(viewMode === 'list' ? 'map' : 'list')}
          className="fixed bottom-24 left-1/2 -translate-x-1/2 flex items-center gap-2 px-6 py-3 rounded-full backdrop-blur-xl shadow-2xl"
          style={{
            background: 'linear-gradient(135deg, rgba(0,0,0,0.95), rgba(20,20,20,0.95))',
            border: '1px solid rgba(212,175,122,0.4)',
            boxShadow: '0 10px 40px rgba(0,0,0,0.5), 0 0 20px rgba(212,175,122,0.2)',
            zIndex: 100,
          }}
          whileTap={{ scale: 0.95 }}
        >
          {viewMode === 'list' ? (
            <>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#D4AF7A" strokeWidth="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
              <span className="text-sm text-[#F5F5F0] font-medium">Map</span>
            </>
          ) : (
            <>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#D4AF7A" strokeWidth="2">
                <line x1="8" y1="6" x2="21" y2="6"/>
                <line x1="8" y1="12" x2="21" y2="12"/>
                <line x1="8" y1="18" x2="21" y2="18"/>
                <line x1="3" y1="6" x2="3.01" y2="6"/>
                <line x1="3" y1="12" x2="3.01" y2="12"/>
                <line x1="3" y1="18" x2="3.01" y2="18"/>
              </svg>
              <span className="text-sm text-[#F5F5F0] font-medium">List</span>
            </>
          )}
        </motion.button>
      )}
    </div>
  );
}
