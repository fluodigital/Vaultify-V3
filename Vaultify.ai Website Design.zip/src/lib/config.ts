/**
 * ⚙️ Vaultify.ai Configuration
 * 
 * 🎯 FOR FIGMA MAKE: Add your API keys directly in this file
 * 
 * Quick Start:
 * 1. Replace 'YOUR_GOOGLE_MAPS_API_KEY_HERE' with your actual Google Maps API key
 * 2. Replace the Firebase config values with your Firebase project credentials
 * 3. (Optional) Add Stripe and Circle keys for payments
 * 
 * See FIGMA_MAKE_SETUP.md for detailed instructions
 */

export const config = {
  /**
   * 🗺️ Google Maps API Key
   * 
   * Where to get it: https://console.cloud.google.com/google/maps-apis
   * What it does: Powers the interactive luxury map on the Dashboard
   * 
   * Example: 'AIzaSyBXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
   */
  googleMapsApiKey: 'AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA',

  /**
   * 🗺️ Google Maps Map ID (Required for Advanced Markers)
   * 
   * Where to get it:
   * 1. Go to https://console.cloud.google.com/google/maps-apis/studio/maps
   * 2. Click "Create Map ID"
   * 3. Name it: "Vaultify Luxury Map"
   * 4. Map type: JavaScript
   * 5. Copy the Map ID and paste below
   * 
   * Example: 'a1b2c3d4e5f6g7h8'
   * 
   * Note: If you don't have a Map ID yet, the map will use standard markers
   */
  googleMapsMapId: 'DEMO_MAP_ID', // Replace with your actual Map ID

  /**
   * 🔥 Firebase Configuration
   * 
   * Where to get it: Firebase Console > Project Settings > Your apps
   * What it does: Powers authentication, database, and all backend functionality
   * 
   * How to find:
   * 1. Go to https://console.firebase.google.com
   * 2. Click your project
   * 3. Click ⚙️ (Settings) > Project settings
   * 4. Scroll down to "Your apps" section
   * 5. Copy the config object
   */
  firebase: {
    apiKey: 'YOUR_FIREBASE_API_KEY',
    authDomain: 'YOUR_PROJECT.firebaseapp.com',
    projectId: 'YOUR_PROJECT_ID',
    storageBucket: 'YOUR_PROJECT.appspot.com',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    appId: 'YOUR_APP_ID',
  },

  /**
   * 💳 Stripe Publishable Key (OPTIONAL)
   * 
   * Where to get it: https://dashboard.stripe.com/apikeys
   * What it does: Enables credit card and wire transfer payments
   * 
   * Note: Use 'pk_test_...' for testing, 'pk_live_...' for production
   * Example: 'pk_test_51XXXXXXXXXXXXXXXXXXXXX'
   */
  stripePublishableKey: 'pk_test_YOUR_STRIPE_KEY',

  /**
   * 🪙 Circle API Key (OPTIONAL)
   * 
   * Where to get it: https://console.circle.com
   * What it does: Enables crypto payments (USDC, USDT, EUROC, DAI)
   * 
   * Note: Required only if you want to accept stablecoin payments
   */
  circleApiKey: 'YOUR_CIRCLE_API_KEY',

  /**
   * 🤖 OpenAI API Key (OPTIONAL - for local testing only)
   * 
   * Where to get it: https://platform.openai.com/api-keys
   * What it does: Powers Alfred AI responses
   * 
   * ⚠️ IMPORTANT: For production, add this to Firebase Functions environment config
   * This should NOT contain a production key for security reasons
   */
  openaiApiKey: 'YOUR_OPENAI_API_KEY',
};

/**
 * Helper function to check if Google Maps is configured
 */
export const isGoogleMapsConfigured = () => {
  return config.googleMapsApiKey !== 'YOUR_GOOGLE_MAPS_API_KEY_HERE' 
    && config.googleMapsApiKey.length > 0;
};

/**
 * Helper function to check if Firebase is configured
 */
export const isFirebaseConfigured = () => {
  return config.firebase.apiKey !== 'YOUR_FIREBASE_API_KEY' 
    && config.firebase.apiKey.length > 0;
};
