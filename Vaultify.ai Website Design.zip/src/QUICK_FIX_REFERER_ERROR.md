# 🔧 QUICK FIX: RefererNotAllowedMapError

## ❌ Error You're Seeing

```
Google Maps JavaScript API error: RefererNotAllowedMapError
Your site URL to be authorized: 
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/preview_page.html
```

## ✅ Solution (2 Minutes)

Your Google Maps API key is restricted to certain domains, and Figma Make's preview domain is not authorized yet.

---

## 🚀 Fix It Now

### Step 1: Go to Google Cloud Console

Click this link: [Google Cloud API Credentials](https://console.cloud.google.com/apis/credentials)

Make sure you're in the correct project (the one with your API key).

---

### Step 2: Find Your API Key

1. Look for your API key in the list (starts with `AIzaSy...`)
2. Click on it to edit

---

### Step 3: Add Figma Make Domains

Scroll down to **"Application restrictions"** section:

**Set restriction type to:**
```
☑️ HTTP referrers (web sites)
```

**Add these referrer patterns:**
```
*.figma.site/*
*.figma.com/*
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/*
```

**Also add (for local testing):**
```
localhost:*
http://localhost/*
https://localhost/*
```

---

### Step 4: Save Changes

1. Click **"Save"** at the bottom
2. Wait 1-2 minutes for changes to propagate
3. Refresh your Figma Make preview

---

## 📋 Complete Referrer List

Copy and paste these into the "Website restrictions" field:

```
*.figma.site/*
*.figma.com/*
localhost:*
http://localhost/*
https://localhost/*
```

If you want to be more specific with your current Figma Make URL:
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/*
```

---

## 🎯 Visual Guide

### In Google Cloud Console:

```
┌─────────────────────────────────────────────────────┐
│ Edit API key                                        │
├─────────────────────────────────────────────────────┤
│                                                     │
│ Application restrictions                            │
│                                                     │
│ ○ None                                             │
│ ● HTTP referrers (web sites)    ← SELECT THIS     │
│ ○ IP addresses                                     │
│                                                     │
│ Website restrictions                                │
│ ┌─────────────────────────────────────────────┐   │
│ │ *.figma.site/*                              │   │
│ │ + Add an item                               │   │
│ └─────────────────────────────────────────────┘   │
│                                                     │
│ Click "+ Add an item" to add more domains          │
│                                                     │
│                    [Cancel]  [Save]                 │
└─────────────────────────────────────────────────────┘
```

---

## ⚡ Quick Copy-Paste

### For Figma Make Only:
```
*.figma.site/*
*.figma.com/*
```

### For Figma Make + Local Testing:
```
*.figma.site/*
*.figma.com/*
localhost:*
http://localhost/*
https://localhost/*
```

### For Production Deployment (add your domain):
```
*.figma.site/*
*.figma.com/*
yourdomain.com/*
www.yourdomain.com/*
```

---

## 🔍 Why This Happens

**Google Maps API keys can be restricted** to only work on specific domains for security.

**Your current restriction:** Probably set to something else or "None"  
**What Figma Make needs:** `*.figma.site/*` pattern

**This is GOOD for security** - it prevents unauthorized use of your API key.

---

## ✅ Verification

After saving and waiting 1-2 minutes:

1. ✅ Refresh your Figma Make preview
2. ✅ Login to Vaultify app
3. ✅ Go to Dashboard → Map
4. ✅ Map should load without errors!

---

## 🆘 Still Not Working?

### Check 1: Wait Longer
- Changes can take up to 5 minutes to propagate
- Try clearing browser cache (Ctrl+Shift+R)

### Check 2: Verify Pattern
- Make sure you used `*.figma.site/*` (with asterisks)
- Don't use just `figma.site` without wildcards

### Check 3: Check the Exact URL
Your error message shows:
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/preview_page.html
```

You can add this EXACT URL if wildcard doesn't work:
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/*
```

### Check 4: Verify API Key
- Make sure you're editing the SAME API key that's in `/lib/config.ts`
- Key should start with: `AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA`

---

## 📱 Mobile vs Desktop

**This error affects BOTH:**
- Figma Make preview (web)
- Mobile view in Figma Make
- Any URL under `*.figma.site/*`

**One fix solves all** - just add the domain patterns.

---

## 🔒 Security Best Practices

### ✅ DO:
- Use HTTP referrer restrictions
- Add only domains you own/use
- Use wildcard patterns for subdomains
- Keep API key in config file (not public repos)

### ❌ DON'T:
- Set restriction to "None" (insecure)
- Share your API key publicly
- Add random domains
- Use API key on unknown sites

---

## 💰 Billing Note

Adding referrer restrictions does NOT increase costs.

**This is purely for security** - it limits where your API key can be used, which is good!

You still get:
- $200/month free credit
- Same pricing tier
- No extra charges

---

## 🎯 Summary

**Problem:** API key not authorized for Figma Make domain  
**Solution:** Add `*.figma.site/*` to HTTP referrers  
**Time:** 2 minutes  
**Cost:** Free  

**Steps:**
1. Go to [API Credentials](https://console.cloud.google.com/apis/credentials)
2. Click your API key
3. Select "HTTP referrers"
4. Add `*.figma.site/*`
5. Save
6. Wait 1-2 minutes
7. Refresh Figma Make preview

---

## ✅ Success Checklist

After applying the fix:

- [ ] Went to Google Cloud Console
- [ ] Found correct API key
- [ ] Selected "HTTP referrers" restriction
- [ ] Added `*.figma.site/*`
- [ ] Added `*.figma.com/*`
- [ ] (Optional) Added `localhost:*`
- [ ] Clicked "Save"
- [ ] Waited 2 minutes
- [ ] Refreshed Figma Make preview
- [ ] Map loads without RefererNotAllowedMapError ✅

---

## 🎉 You're Done!

Once you see the map loading, you're all set!

**Next:** (Optional) Set up Map ID for luxury markers  
**Guide:** `GOOGLE_MAPS_MAP_ID_SETUP.md`

---

*Quick fix completed - back to building luxury experiences!*
