# 🔧 Complete Guide: RefererNotAllowedMapError

## 📖 Table of Contents
1. [What This Error Means](#what-this-error-means)
2. [Quick Fix (2 Minutes)](#quick-fix-2-minutes)
3. [Why This Happens](#why-this-happens)
4. [Step-by-Step Fix](#step-by-step-fix)
5. [Verification](#verification)
6. [Troubleshooting](#troubleshooting)

---

## What This Error Means

### The Error Message
```
❌ Google Maps JavaScript API error: RefererNotAllowedMapError
https://developers.google.com/maps/documentation/javascript/error-messages#referer-not-allowed-map-error

Your site URL to be authorized:
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/preview_page.html
```

### Translation
Your Google Maps API key is configured to only work on specific domains (for security), and **Figma Make's preview domain is not on the allowed list**.

This is actually a **good thing** - it means your API key is protected! We just need to add Figma Make to the allowed domains.

---

## Quick Fix (2 Minutes)

### ⚡ Super Quick Steps

1. **Open:** [https://console.cloud.google.com/apis/credentials](https://console.cloud.google.com/apis/credentials)

2. **Click:** Your API key (starts with `AIzaSy...`)

3. **Select:** Under "Application restrictions" → `● HTTP referrers (web sites)`

4. **Add these domains:**
   ```
   *.figma.site/*
   *.figma.com/*
   localhost:*
   ```

5. **Click:** "Save" button at the bottom

6. **Wait:** 1-2 minutes

7. **Refresh:** Your Figma Make preview (Ctrl+Shift+R or Cmd+Shift+R)

**Done!** ✅ Map should now work.

---

## Why This Happens

### Security Feature
Google Maps API keys can be restricted to specific domains to prevent unauthorized use. This stops someone from stealing your API key and using it on their own website (which would use up your free credits or charge your billing account).

### Figma Make URLs
When you preview your Vaultify app in Figma Make, it runs on a Figma-controlled domain:
```
https://[unique-id]-figmaiframepreview.figma.site/preview_page.html
```

Each Figma Make project gets a unique subdomain, but they all end with `.figma.site`.

### The Problem
If your API key restrictions don't include `*.figma.site/*`, Google Maps will refuse to load, showing the RefererNotAllowedMapError.

### The Solution
Add wildcard patterns like `*.figma.site/*` to allow ALL Figma Make preview domains.

---

## Step-by-Step Fix

### Step 1: Access Google Cloud Console

1. Go to: [https://console.cloud.google.com/](https://console.cloud.google.com/)
2. Make sure you're signed in with the Google account that owns the API key
3. **Verify you're in the correct project** (top-left dropdown)
   - Should be the project where you created your Maps API key

### Step 2: Navigate to API Credentials

1. Click the hamburger menu (☰) in the top-left
2. Navigate to: **APIs & Services** → **Credentials**
3. Or use direct link: [https://console.cloud.google.com/apis/credentials](https://console.cloud.google.com/apis/credentials)

### Step 3: Find Your API Key

In the "API keys" section, look for your key:
- **Name:** Usually "API key 1" or custom name
- **Key:** Starts with `AIzaSy...`
- **Your key:** `AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA`

Click on the key name or the pencil/edit icon.

### Step 4: Set Application Restrictions

Scroll down to the **"Application restrictions"** section.

You'll see three radio button options:
- ○ None
- ○ HTTP referrers (web sites)
- ○ IP addresses (web servers, cron jobs, etc.)

**Select:** `● HTTP referrers (web sites)`

### Step 5: Add Website Restrictions

You'll now see a "Website restrictions" section with a text input.

**Add these domains one by one:**

#### For Figma Make (REQUIRED):
```
*.figma.site/*
```
Click "+ Add an item" or press Enter

```
*.figma.com/*
```
Click "+ Add an item" or press Enter

#### For Local Development (OPTIONAL but recommended):
```
localhost:*
```
Click "+ Add an item" or press Enter

```
http://localhost/*
```
Click "+ Add an item" or press Enter

```
https://localhost/*
```

#### For Your Custom Domain (if you deploy elsewhere):
```
yourdomain.com/*
```
```
www.yourdomain.com/*
```
```
*.yourdomain.com/*
```

### Step 6: API Restrictions (Verify)

Scroll down to **"API restrictions"** section.

**Recommended setting:**
- Select: `● Restrict key`
- Choose: `☑ Maps JavaScript API`

This ensures the key can ONLY be used for Google Maps, adding another layer of security.

### Step 7: Save Changes

1. Scroll to the bottom of the page
2. Click the blue **"Save"** button
3. Wait for the confirmation message

### Step 8: Wait for Propagation

Changes can take **1-5 minutes** to propagate globally.

**What to do:**
- Wait at least 2 minutes
- Clear your browser cache
- Refresh your Figma Make preview

### Step 9: Test

1. Go back to your Figma Make preview
2. Press `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac) to hard refresh
3. Navigate to Dashboard → Click "Map" button
4. Map should load without errors! ✅

---

## Verification

### ✅ Success Indicators

**In Google Cloud Console:**
```
Application restrictions: HTTP referrers
Website restrictions:
  1. *.figma.site/*
  2. *.figma.com/*
  3. localhost:*
  (Status: Saved)
```

**In Browser Console (F12):**
```
✅ No RefererNotAllowedMapError
✅ Map loads successfully
✅ Markers appear
```

**Visual Confirmation:**
- Map displays with dark luxury theme
- 10 champagne gold markers visible
- No error overlays
- Zoom controls work
- Click interactions work

---

## Troubleshooting

### Issue: Still Getting Error After 5 Minutes

**Check 1: Verify Exact Domains**
Make sure you used:
- `*.figma.site/*` (with asterisks and forward slashes)
- NOT `figma.site` or `*.figma.site` or `figma.site/*`

**Check 2: Verify You Edited the Right Key**
- Open `/lib/config.ts`
- Check: `googleMapsApiKey: 'AIzaSyCR7rPFghlyQ6Zu1dGAULZEczMcU2-5dZA'`
- Make sure this EXACT key is what you edited in Google Cloud Console

**Check 3: Clear Browser Cache**
```bash
# Chrome/Edge
Ctrl + Shift + Delete → Clear browsing data → Cached images and files

# Firefox  
Ctrl + Shift + Delete → Cache → Clear Now

# Safari
Cmd + Option + E

# Or just use Incognito/Private browsing
```

**Check 4: Verify Restrictions Are Set**
Go back to the API key settings and confirm:
- ● HTTP referrers is selected
- Domains are listed
- Changes were saved

---

### Issue: Error Says Different URL

**Your error shows:**
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/preview_page.html
```

**If wildcard `*.figma.site/*` doesn't work:**

Try adding the **exact URL** as well:
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/*
```

Note: This is less flexible (won't work if Figma changes your preview URL).

---

### Issue: Map Loads But Shows Different Error

**If you see "Map ID" error:**
- This is different - see `GOOGLE_MAPS_MAP_ID_SETUP.md`
- Map will still work with standard markers

**If you see "Billing not enabled":**
- Go to Google Cloud Console → Billing
- Set up a billing account (required for Google Maps)
- Free tier: $200/month credit

**If you see "API not enabled":**
- Go to: APIs & Services → Library
- Search: "Maps JavaScript API"
- Click "Enable"

---

### Issue: Multiple API Keys

**If you have multiple API keys:**
1. Find the one that matches `/lib/config.ts`
2. Make sure you're editing that specific key
3. You can rename keys in Google Cloud Console for easy identification

**To verify which key is being used:**
1. Open browser DevTools (F12)
2. Go to Network tab
3. Look for request to `maps.googleapis.com`
4. Check the `key=` parameter in the URL

---

## Understanding the Domain Patterns

### Wildcard Patterns Explained

```
*.figma.site/*
│  │        │
│  │        └─ Matches any path (/preview_page.html, /foo/bar, etc.)
│  └─────────── Matches the domain
└──────────────── Matches any subdomain (abc-123.figma.site, xyz.figma.site, etc.)
```

**What this allows:**
- `https://anything.figma.site/any/path`
- `https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/preview_page.html`
- `https://new-project.figma.site/`

**What this blocks:**
- `https://evil-site.com` ❌
- `https://not-figma.site` ❌
- `https://figma.site.fake.com` ❌

### Why Use Wildcards

**Pros:**
- Works for all your Figma Make projects
- Works if Figma changes your preview URL
- One setup for all previews
- More flexible

**Cons:**
- Slightly less restrictive
- But still secure (only works on Figma's domains)

### Alternative: Specific URL

If you prefer maximum security, use the exact URL:
```
https://e4b4834f-371c-4975-b036-7d6fb9dd7121-figmaiframepreview.figma.site/*
```

**Pros:**
- Maximum security
- Only works on this exact project

**Cons:**
- Won't work on other Figma projects
- Won't work if Figma changes the URL
- Need to update if you republish

---

## Security Best Practices

### ✅ Recommended Setup

**For Figma Make Development:**
```
Application restrictions: HTTP referrers
Website restrictions:
  - *.figma.site/*
  - *.figma.com/*
  - localhost:*

API restrictions: Restrict key
Allowed APIs:
  - Maps JavaScript API
```

**For Production (if deploying to your domain):**
```
Application restrictions: HTTP referrers
Website restrictions:
  - yourdomain.com/*
  - www.yourdomain.com/*
  - *.yourdomain.com/*

API restrictions: Restrict key
Allowed APIs:
  - Maps JavaScript API
```

### 🔒 Why Restrictions Matter

**Without restrictions:**
- Anyone can use your API key
- They could drain your free credits
- You could be charged for their usage
- No way to track unauthorized use

**With restrictions:**
- Only your domains can use the key
- Protects your billing account
- Professional security practice
- Prevents API key theft

### 💡 Pro Tips

1. **Use separate API keys** for development and production
2. **Set billing alerts** at $10, $50, $100
3. **Rotate keys** if you suspect they've been compromised
4. **Never commit API keys** to public repositories
5. **Monitor usage** in Google Cloud Console dashboard

---

## Cost & Billing

### Free Tier
- **$200/month** free credit
- Covers ~28,000 map loads
- More than enough for testing and small deployments

### Pricing After Free Tier
- **$7 per 1,000** map loads
- Static maps: $2 per 1,000
- Your usage (estimated): $0-5/month for testing

### No Extra Cost for Restrictions
Adding domain restrictions is **completely free** and doesn't affect pricing.

---

## Common Questions

### Q: Will this affect my local development?
**A:** Only if you remove `localhost:*`. Keep it in the list to test locally.

### Q: Do I need to do this for every Figma project?
**A:** No! The wildcard `*.figma.site/*` works for all Figma Make projects.

### Q: Can someone steal my API key from browser DevTools?
**A:** They can SEE it, but they can't USE it on their domain (thanks to restrictions).

### Q: Should I use "None" for easier testing?
**A:** NO! Always use restrictions. It only takes 2 minutes to set up properly.

### Q: What if I deploy to Vercel/Netlify/etc later?
**A:** Just add your deployment domain to the restrictions list.

### Q: How often should I check my API usage?
**A:** Weekly during development, monthly in production. Set up billing alerts!

---

## Summary

### The Problem
```
Google Maps API key → Not allowed on Figma domains → RefererNotAllowedMapError
```

### The Solution
```
Google Cloud Console → Add *.figma.site/* → Save → Wait 2 min → Refresh → Works! ✅
```

### Time Required
- **Setup:** 2 minutes
- **Propagation:** 1-5 minutes
- **Total:** Under 10 minutes

### Complexity
- **Difficulty:** Easy
- **Technical skill:** Basic (follow screenshots)
- **One-time setup:** Yes (unless you change API keys)

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────┐
│ REFERER ERROR QUICK FIX                         │
├─────────────────────────────────────────────────┤
│                                                 │
│ 1. console.cloud.google.com/apis/credentials    │
│ 2. Click API key                                │
│ 3. Select "HTTP referrers"                      │
│ 4. Add: *.figma.site/*                         │
│ 5. Add: *.figma.com/*                          │
│ 6. Add: localhost:*                             │
│ 7. Save                                         │
│ 8. Wait 2 minutes                               │
│ 9. Refresh preview                              │
│                                                 │
│ ✅ DONE                                         │
└─────────────────────────────────────────────────┘
```

---

## Related Documentation

- **FIX_NOW.md** - Ultra-quick 1-page fix
- **QUICK_FIX_REFERER_ERROR.md** - Step-by-step with screenshots
- **GOOGLE_MAPS_SETUP.md** - Complete Maps setup guide
- **SETUP_COMPLETE.md** - Overall setup checklist
- **MAP_STATUS.md** - Current map status
- **ERRORS_FIXED.md** - All errors and solutions

---

**Your map will work perfectly after this fix!** 🎉

The RefererNotAllowedMapError is the most common Google Maps error, and it's quick to fix. Just add the Figma domains, wait a minute, and you're good to go!

---

*Luxury that listens. Intelligence that acts.*
