
  # Vaultify.ai Website Design

  This is a code bundle for Vaultify.ai Website Design. The original project is available at https://www.figma.com/design/Eeu2MevuVs6kQfPreNyHQk/Vaultify.ai-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  